import React, { useState, useEffect } from "react";
import { axiosInstance, endPoint } from "../../endPoint/api";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";

const NewQuestion = () => {
  const [title, setTitle] = useState("");
  const [questionDescription, setQuestionDescription] = useState("");

const navigate = useNavigate()

  const handlePost = async (e) => {
    e.preventDefault();
    const token = Cookies.get("token");

    try {
      await axiosInstance.post(
        endPoint.QUESTIONS,
        {
          question: title,
          questionDescription: questionDescription,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setTitle("")
      setQuestionDescription("")
      navigate()
    } catch (error) {
      console.log("Error posting question:", error);
    }
  };

  return (
    <div>
      <form onSubmit={handlePost}>
        <div className="mb-3">
          <textarea
            name="question"
            placeholder="Title"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <textarea
            name="questionDescription"
            style={{ height: "200px" }}
            placeholder="Question Description..."
            className="form-control"
            value={questionDescription}
            onChange={(e) => setQuestionDescription(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Post Your Question
        </button>
      </form>
    </div>
  );
};

export default NewQuestion;
